package com.hakaneroztekin.glassdoorScraper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlassdoorScraperApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlassdoorScraperApplication.class, args);
	}

}

